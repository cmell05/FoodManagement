package model;

@SuppressWarnings("serial")
public class InvalidPasswordException extends Exception {

	public InvalidPasswordException(String s) {
		super(s);
	}
	
	

}
