package model;

@SuppressWarnings("serial")
public class InvalidRoleException extends Exception {

	public InvalidRoleException(String s) {
		super(s);
	}

}
